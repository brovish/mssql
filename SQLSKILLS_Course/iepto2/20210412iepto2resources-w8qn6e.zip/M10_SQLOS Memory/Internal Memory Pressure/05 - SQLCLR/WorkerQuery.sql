USE AdventureWorks2008R2;

WHILE 1=1
BEGIN

	EXECUTE ConsumeExcessiveMemory @size_mb = 256;

END