
-- Attach database
USE [master]
GO
EXEC master.dbo.sp_detach_db @dbname = N'Credit2'
GO
