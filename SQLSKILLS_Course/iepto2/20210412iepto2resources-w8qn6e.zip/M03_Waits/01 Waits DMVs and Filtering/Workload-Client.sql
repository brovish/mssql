USE [master];
GO

SET NOCOUNT ON;
GO

WHILE (1 = 1)
BEGIN
	INSERT INTO [HotSpot].[dbo].[HotSpotTable] DEFAULT VALUES;
END;
GO