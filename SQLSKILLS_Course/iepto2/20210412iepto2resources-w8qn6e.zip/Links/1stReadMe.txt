Remember, the links within the "viewing" pdf are LIVE. You can use those directly. This is just a set of additional links based on discussions and/or other references!

Enjoy