Hey there IEPTO2 Attendees - 

Lots of resources here. I thought a readme might be a good idea. And, I thought I'd try a new setup for you... I put ALL of our demo scripts into one large directory structure. So, definitely let me know if something doesn't work quite right...

And, of course, let me know if you have any questions! 

As for a quick list:
* All of the demos are in directories related to their module. Most are relatively self-explanatory but if you can't find a specific script do a simple search for something related to a script name and you'll probably find it! 

* SQLprocs - I've put the latest version sp_SQLskills_helpindex script there AND Randolph tweaked the find dupes scripts recently to ignore columnstore indexes so I added those. I need to do a bunch of updates to these on my blog but this is really great for now for you guys! 

* Other resources:
    - Chats - has all of our chats from class
    - links - has all of the links that I referenced and I also added a few!

* PlanStability directory: The Whiteboard file that I drew during class is in there (there was really only one). But I also included my Multipurpose Procs lecture that I often give at user groups! Given that you have the video, I didn't annotate the diagram. But, if you have questions - let me know!

And, I think that's it!! If you don't find something that you thought would be within these resources, shoot me an email. And, THANKS for joining us for our latest IEPTO2 delivery, it was great fun!

Thanks,
Kimberly

Kimberly L. Tripp
SQLskills.com
email: Kimberly@SQLskills.com