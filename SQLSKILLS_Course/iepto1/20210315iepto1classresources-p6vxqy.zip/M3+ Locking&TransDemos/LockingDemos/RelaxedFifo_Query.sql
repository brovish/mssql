USE AdventureWorksDW2008_ModifiedSalesKey
go

SELECT * 
FROM factinternetsales --WITH (NOLOCK)
