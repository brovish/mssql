sp_bindsession 'paste token results from first session here'

select * from credit.dbo.member
-- This query can see the modifications from the sessions to which we are bound.