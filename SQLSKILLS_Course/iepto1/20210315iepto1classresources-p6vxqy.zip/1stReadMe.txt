Hey there IEPTO1 Attendees - 

Lots of resources here. I thought a readme might be a good idea. And, I thought I'd try a new setup for you... I put ALL of our demo scripts into one large directory structure. So, definitely let me know if something doesn't work quite right...

And, of course, let me know if you have any questions! 

As for a quick list:
* All of the demos are in directories related to their FIRST module. Most are relatively self-explanatory but if you can't find a specific script do a simple search for something related to a script name and you'll probably find it!

* SQLprocs - I've put the latest version sp_SQLskills_helpindex script there AND Randolph tweaked the find dupes scripts recently to ignore columnstore indexes so I added those. I need to do a bunch of updates to these on my blog but this is really great for now for you guys! I also put the modified PlanCache proc that we discussed there (that looks at plan properties when multiple exist in cache).

* Other resources:
    - Chats - has all of our chats from class
    - links - has all of the links that I referenced and I also added the Hashing and Hash Teams article as well as the Query Evaluation Techniques for Large Databases. I'd recommend only printing subsets of these (or, reading electronically).

* Videos: If you want to watch these, I've tried to order them the way in which I'd recommed you review them.

* The Whiteboard file that I drew during class is in there. Given that you have the video, I didn't annotate this. But, if you have questions - let me know!

And, I think that's it!! If you don't find something that you thought would be within these resources, shoot me an email. And, THANKS for joining me for our very first ONLINE delivery of our IEPTO1; it was great fun!

Thanks,
Kimberly

Kimberly L. Tripp
SQLskills.com
email: Kimberly@SQLskills.com