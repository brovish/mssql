Hey there IEVLT Attendees - 

Lots of resources here. I thought a readme might be a good idea. 

Definitely let me know if you have any questions! 

As for a quick list:
* I updated the two course workbook files on the main page:
    - SQLskillsOnlineIEVLT_Workshop-ForPrint.pdf 
	    2 slides per side - to save a few trees, if you even want to print?
    - SQLskillsOnlineIEVLT_Workshop-FullScreenSlides.pdf
	    Best for onscreen viewing
    - In this zip there's a "markup" version that includes the drawings. I'm not even
            sure if thi is helpful but I did include it.

* Two primary demo directories:
    - PartitioningDemoScripts directory is what I used for my demos during the course.

    - PartitalDatabaseAvailabilityDemoScripts
      this has partitioning with ranges of numbers (instead of dates) and all of the code
      for the partial database availability demos in the online videos

* Other resources:
    - lots of links and references from the review module and as well as a few from
      questions and discussions:
      * For Backup / Resources resources AND Compression, I went back and updated an
            old blog post with new links, etc. as it has even MORE really good stuff
            on it. Check out that link in the zip. 
      *	For Sharding on Azure and "scale out" look at the "Sharding on Azure..." links
      * For Data loading as well as feature updates in 2008+ and then 2016+ see the
            "Data Loading ..." scripts
      * Don't forget that there are a bunch of hidden slides. And, a few NEW slides 
      * The videos are ordered the way in which I'd recommed you review them.
      * Randolph tweaked a few of the sps for index help. I've included those here too.
        See the SQLprocs directory!

* Most of the other links/resources are self-explanatory... ;-)

And, if you don't find something that you thought would be within these resources, just shoot
 me an email. So.... I think that's it (yep, that's all ;-)!! 

Finally, ***THANKS*** for joining our IEVLT ONLINE Immersion Event; I really did have 
a great time!!

Thanks,
Kimberly

Kimberly L. Tripp
SQLskills.com