:ON ERROR IGNORE
go

USE CreditPT
go

SET NOCOUNT ON
go

WHILE 1=1
BEGIN
	:r AddNewCharge.sql  
	WAITFOR DELAY '00:00:00.050'
END
go