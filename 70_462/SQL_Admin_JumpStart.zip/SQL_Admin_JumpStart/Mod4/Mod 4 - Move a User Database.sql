
/*

Move a Database to another Instance

*/

--------------------------------------------------------
-- Create a Database  
--------------------------------------------------------


-- Make sure you're connected to the Proseware Instance.
Create Database DB2BMoved;
GO

-- Determine current filenames and locations...

Use DB2BMoved;
GO

Select * from sys.database_files;

--------------------------------------------------------
-- Detach a Database  
--------------------------------------------------------

Use Master
Go

--All users must be disconnected from the DB in order to detach.

sp_Detach_DB 'DB2BMoved'

-- Then MANUALLY copy only the database file, and then rename the original file 
-- Change the Connection window to another Instance
-- Re-attach the database

Create Database DB2BMoved
ON
(Filename = 'D:\MSSQLServer\DB2BMoved.mdf')
FOR ATTACH;					-- Notice, only the data file location was specified.
						-- This will recreate a log file "on the fly".
-- or...

SP_ATTACH_DB 'DB2BMoved'
	,'D:\MSSQLServer\DB2BMoved.mdf'
	,'L:\MSSQLServer\DB2BMoved_log.LDF'	-- This requires both the original data file and log file to be moved
							-- to the newly specified location.
-------------------------------------
-- Cleanup
-------------------------------------


