--Module 16 - Demonstration 1A

-- Step 1: Run DBCC CHECKDB with Default options
--         Note the output and point to the last message which indicates
--         that there were no errors.

DBCC CHECKDB('MarketDev');
GO

-- Step 2: Run DBCC CHECKDB without informational messages
--         Note the difference in output. Only error messages would 
--         appear with this option.

DBCC CHECKDB('MarketDev') WITH NO_INFOMSGS;
GO

-- Step 3: Restore a corrupt database
--         Note that this database was backed up in a corrupted state.

RESTORE DATABASE CorruptDB				-- Adjust paths as necessary.
FROM DISK = 'D:\SQL_Admin_JumpStart\Mod4\CorruptDB.bak'
WITH MOVE 'Northwind' TO 'D:\MKTG\CorruptDB.mdf',
     MOVE 'Northwind_Log' TO 'L:\MKTG\CorruptDB.ldf';
GO

-- Step 4: Run DBCC CHECKDB against CorruptDB	
--         Note that 4 errors are returned and note that
--         the last line of output tells you the minimum repair
--         level required. The table Orders has issues.

DBCC CHECKDB('CorruptDB') WITH NO_INFOMSGS;
GO

-- Step 5: Try to access the Orders table
--         Note the error 824 that is returned. This is a commonly
--         seen error that relates to disk subsystem problems.

SELECT * FROM CorruptDB.dbo.Orders;
GO

-- Step 6: Note that the error might only apply to particular pages
--         in the table. Try to access a specific order and note
--         that the row is returned because the query does not
--         access the corrupted page or pages.

SELECT * FROM CorruptDB.dbo.Orders WHERE OrderID = 10400;
GO

-- Step 7: The best solution at this point would be to restore from
--         a backup that was created before the corruption occurred.
--         In this case, the only backup we have was corrupt so we 
--         have no option but to try to recover the database. Note
--         this is an emergency option and should only be used as an
--         absolutely last resort. No guarantee on logical consistency
--         in the database (such as foreign key constraints) is provided.
--         Set the database in SINGLE_USER mode and repair it.

ALTER DATABASE CorruptDB SET SINGLE_USER WITH ROLLBACK IMMEDIATE;
GO

DBCC CHECKDB('CorruptDB', REPAIR_ALLOW_DATA_LOSS);
GO

ALTER DATABASE CorruptDB SET MULTI_USER WITH ROLLBACK IMMEDIATE;
GO

-- Step 8: Check if we can access the Orders table

SELECT * FROM CorruptDB.dbo.Orders;
GO

-- Step 9: Run DBCC CHECKDB to check if the internal database
--         structure is consistent

DBCC CHECKDB('CorruptDB') WITH NO_INFOMSGS;
GO

-- Step 10: Did we lose data though?
--			Note that there is a foreign key between the Orders 
--          and the [Order Details] tables based on OrderID.
--          This means that an order must exist for each order detail.
--          We'll query for order details entries that do not have 
--          matching orders.
--          (Note how much data was lost)

SELECT DISTINCT OrderID 
FROM CorruptDB.dbo.[order details] AS od
WHERE NOT EXISTS (SELECT 1 
                  FROM CorruptDB.dbo.Orders AS o
                  WHERE o.orderid = od.orderid);
GO
	
-- Step 11: Drop the database

DROP DATABASE CorruptDB;
GO
