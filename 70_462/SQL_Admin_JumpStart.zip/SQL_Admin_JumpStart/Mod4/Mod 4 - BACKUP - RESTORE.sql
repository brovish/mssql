--------------------------------------------------------
/* 
Creator: George Squillace, SQLPadawan@e-Squillace.com.

--------------------------------------------------------
-- Demonstrate aspects of Backup Devices, the BACKUP and RESTORE T-SQL statements, and the use of Management Studio to perform restoration and recovery.
--------------------------------------------------------

*/

---------------------------
---------------------------
--------Run Code From Here to the next similar marker.
---------------------------
---------------------------



--------------------------------------------------------
-- Make necessary backup path
--------------------------------------------------------

EXEC xp_CMDSHELL 'md c:\BackupDevs'	-- This, of course, requires enabling xp_CMDSHELL using sp_Configure.

--------------------------------------------------------
-- Make necessary backup devices, one each for Full, Differential, and Log backups. 
--------------------------------------------------------

-- Make sure the file system path... 
	-- that specifies the device location ACTUALLY EXISTS!

EXEC MASTER.dbo.sp_AdDumpDevice  
	@DevType = N'Disk'
	, @LogicalName = N'FullBackupDev'
	, @PhysicalName = N'c:\BackupDevs\FullBackupDev.bak';
GO

EXEC MASTER.dbo.sp_AdDumpDevice  
	@DevType = N'Disk'
	, @LogicalName = N'Differential_BackupDev'
	, @PhysicalName = N'c:\BackupDevs\Differential_BackupDev.bak';
GO

EXEC MASTER.dbo.sp_AdDumpDevice  
	@DevType = N'Disk'
	, @LogicalName = N'Log_BackupDev'
	, @PhysicalName = N'c:\BackupDevs\Log_BackupDev.bak';
GO

/*
	In Object Explorer expand "Server Objects" and then expand "Backup Devices".
	Right-click on any of the backup devices, such as "Log_BackupDev", get Properties, and click on the "Media Contents" page. 
	This will fail until at least one backup to the device has been performed.
*/

--------------------------------------------------------
-- Make a database for test purposes.
--------------------------------------------------------

USE MASTER;
GO

Create Database ManufacturingDB	;
GO

USE ManufacturingDB;
GO

Create Schema MFG;
GO

--------------------------------------------------------
-- Create Tables in the Database.
--------------------------------------------------------

	Create Table MFG.Table1
		(
			Col1 INT IDENTITY(100,5)
			,Col2 nvarchar(20) Default 'Campania'
			,Col3 Datetime Default GetDate()
			,Col4 varchar(30) Default Current_User
		);

	Create Table MFG.Table2
		(
			Col1 INT IDENTITY(300,5)
			,Col2 nvarchar(20) Default 'Piemonte'
			,Col3 Datetime Default GetDate()
			,Col4 varchar(30) Default Current_User
		);
		
		Create Table MFG.Table3	
		(
			Col1 INT IDENTITY(500,5)
			,Col2 nvarchar(20) Default 'Roma'
			,Col3 Datetime Default GetDate()
			,Col4 varchar(30) Default Current_User
		);
GO

--------------------------------------------------------
-- Perform a Full Backup to the appropriate device.
--------------------------------------------------------

BACKUP DATABASE [ManufacturingDB] 
TO  [FullBackupDev] 
WITH	FORMAT
		, INIT
		,  MEDIADESCRIPTION = N'ManufacturingDB_FullBackup'
		,  MEDIANAME = N'ManufacturingDB_FullBackup'
		,  NAME = N'ManufacturingDB-Full Database Backup'
		,  CHECKSUM
GO


--------------------------------------------------------
-- Make changes to the database.
--------------------------------------------------------
	Insert INTO MFG.Table1 Default Values	;
	Insert INTO MFG.Table1 Default Values	;
	Insert INTO MFG.Table1 Default Values	;

--------------------------------------------------------
-- Back up the Log to the Log Device to record the recent changes.
--------------------------------------------------------

BACKUP LOG [ManufacturingDB] 
TO  [Log_BackupDev] 
WITH	NOFORMAT
		, NOINIT
		,  NAME = N'ManufacturingDB-Transaction Log  Backup'
		,  CHECKSUM
GO

--------------------------------------------------------
-- Make more changes to the database.
--------------------------------------------------------

	Insert INTO MFG.Table2 Default Values	;
	Insert INTO MFG.Table2 Default Values	;
	Insert INTO MFG.Table2 Default Values	;

--------------------------------------------------------
-- Back up the Log to the Log Device to record the recent changes.
--------------------------------------------------------

BACKUP LOG [ManufacturingDB] 
TO  [Log_BackupDev] 
WITH	NOFORMAT
		, NOINIT
		,  NAME = N'ManufacturingDB-Transaction Log  Backup'
		,  CHECKSUM
GO

--------------------------------------------------------
-- Make more changes to the database.
--------------------------------------------------------
	
	Insert INTO MFG.Table3 Default Values	;
	Insert INTO MFG.Table3 Default Values	;
	Insert INTO MFG.Table3 Default Values	;

--------------------------------------------------------
-- Back up the Log to the Log Device to record the recent changes.
--------------------------------------------------------

BACKUP LOG [ManufacturingDB] 
TO  [Log_BackupDev] 
WITH	NOFORMAT
		, NOINIT
		,  NAME = N'ManufacturingDB-Transaction Log  Backup'
		,  CHECKSUM

GO	

--------------------------------------------------------
-- Make more changes to the database.
--------------------------------------------------------

	Insert INTO MFG.Table1 Default Values	;
	Insert INTO MFG.Table1 Default Values	;
	Insert INTO MFG.Table1 Default Values	;

	Insert INTO MFG.Table2 Default Values	;
	Insert INTO MFG.Table2 Default Values	;
	Insert INTO MFG.Table2 Default Values	;
	
	Insert INTO MFG.Table3 Default Values	;
	Insert INTO MFG.Table3 Default Values	;
	Insert INTO MFG.Table3 Default Values	;

GO	


--------------------------------------------------------
-- Perform a Differential Backups to the Differential Device.
--------------------------------------------------------

BACKUP DATABASE [ManufacturingDB] 
TO  [Differential_BackupDev] 
WITH	DIFFERENTIAL 
		, NOFORMAT
		, NOINIT
		, NAME = N'ManufacturingDB-Differential Database Backup'
		, CHECKSUM
GO

--------------------------------------------------------
-- Make MORE CHANGES to the database and perform Log Backups to the Log Device after the Differential backup.
--------------------------------------------------------

	Insert INTO MFG.Table1 Default Values	;
	Insert INTO MFG.Table1 Default Values	;
	Insert INTO MFG.Table1 Default Values	;

--------------------------------------------------------
-- Back up the Log to the Log Device to record the recent changes.
--------------------------------------------------------

BACKUP LOG [ManufacturingDB] 
TO  [Log_BackupDev] 
WITH	NOFORMAT
		, NOINIT
		,  NAME = N'ManufacturingDB-Transaction Log  Backup'
		,  CHECKSUM
GO

--------------------------------------------------------
-- Make more changes to the database.
--------------------------------------------------------

	Insert INTO MFG.Table2 Default Values	;
	Insert INTO MFG.Table2 Default Values	;
	Insert INTO MFG.Table2 Default Values	;

--------------------------------------------------------
-- Perform a Differential Backups to the Differential Device. This will illustrate how Differential backups are cumulative. 
	-- That is, only one DIFF restore will be useful for recovery.
--------------------------------------------------------

BACKUP DATABASE [ManufacturingDB] 
TO  [Differential_BackupDev] 
WITH	DIFFERENTIAL 
		, NOFORMAT
		, NOINIT
		, NAME = N'ManufacturingDB-Differential Database Backup'
		, CHECKSUM
GO

--------------------------------------------------------
-- Make more changes to the database.
--------------------------------------------------------

	Insert INTO MFG.Table2 Default Values	;
	Insert INTO MFG.Table2 Default Values	;
	Insert INTO MFG.Table2 Default Values	;

--------------------------------------------------------
-- Back up the Log to the Log Device to record the recent changes.
--------------------------------------------------------

BACKUP LOG [ManufacturingDB] 
TO  [Log_BackupDev] 
WITH	NOFORMAT
		, NOINIT
		,  NAME = N'ManufacturingDB-Transaction Log  Backup'
		,  CHECKSUM
GO

--------------------------------------------------------
-- Make more changes to the database.
--------------------------------------------------------
	
	Insert INTO MFG.Table3 Default Values	;
	Insert INTO MFG.Table3 Default Values	;
	Insert INTO MFG.Table3 Default Values	;

--------------------------------------------------------
-- Back up the Log to the Log Device to record the recent changes.
--------------------------------------------------------

BACKUP LOG [ManufacturingDB] 
TO  [Log_BackupDev] 
WITH	NOFORMAT
		, NOINIT
		,  NAME = N'ManufacturingDB-Transaction Log  Backup'
		,  CHECKSUM

GO	

--------------------------------------------------------
-- Time to get some facts...
--------------------------------------------------------

/* 
	In Object Explorer expand "Server Objects" and then expand "Backup Devices".
	Right-click on the Log_BackupDev, get Properties, and click on the "Media Contents" page. 
	Observe the media content once again.
	Right-click on the Differential_BackupDev, get Properties, and click on the "Media Contents" page. 
	There should be two files in the Differential device.
*/

--------------------------------------------------------
-- Make more changes to the database.
--------------------------------------------------------

	Insert INTO MFG.Table1 Default Values	;
	Insert INTO MFG.Table1 Default Values	;
	Insert INTO MFG.Table1 Default Values	;

---------------------------
---------------------------
--------To this marker-----
---------------------------
---------------------------

----------------------------------------------------------------------------------------------
--Return to this file after the topic on RESTORE.
----------------------------------------------------------------------------------------------

--------------------------------------------------------
-- Perform a Tail Log Backup (use the GUI, or the code below) to an ad-hoc file.
--------------------------------------------------------

/* 
	In the GUI, right click on the database, choose Tasks, choose Backup. Select a Transaction Log backup. 
	On the Options page look under the "Transaction Log" section. Choose "Back up the Tail of the Log...".  
*/

Use MASTER
GO

BACKUP LOG [ManufacturingDB] 
TO  DISK = N'C:\BackupDevs\MFG_DB-Tail_Log_Bkup.bak' 
WITH	NO_TRUNCATE 
		, NOFORMAT
		, NOINIT
		,  NAME = N'ManufacturingDB-Transaction Log TAIL Backup'
		, NORECOVERY , CHECKSUM	

-- This puts the database in a RESTORING state {refresh the list of databases in Object Explorer}.
GO

-- Notice the database was immediately placed into a RESTORING state.

--------------------------------------------------------
-- Now, use Management Studio to perform a recovery of the database.
--------------------------------------------------------

/* 
	In SSMS right click on the ManufacturingDB, choose Tasks and then choose Restore, and then "Database...".	

	Notice that Management Studio "knows" exactly which backups are required to complete restoration!
	MAKE SURE the "Restore WITH RECOVERY" option is used on the OPTIONS page. */
		
-- Notice, the database has now been recovered successfully.
-- Observe, the final change made was captured with the Tail Log restore.

--------------------------------------------------------
-- Query the Tables to see if the data returned as expected.
--------------------------------------------------------

Use ManufacturingDB;
GO

	Select * from MFG.Table1 Order by Col1 DESC
	Select * from MFG.Table2 Order by Col1 DESC
	Select * from MFG.Table3 Order by Col1 DESC

	-- Alternately, display only the largest IDENTITY value in each table...

	Select 'MFG.Table1' as TableName, IDENT_CURRENT('MFG.Table1') As Largest_IDENT_Val
	UNION
	Select 'MFG.Table2' as TableName, IDENT_CURRENT('MFG.Table2') As Largest_IDENT_Val
	UNION
	Select 'MFG.Table3' as TableName, IDENT_CURRENT('MFG.Table3') As Largest_IDENT_Val;

--------------------------------------------------------
-- Let's DAMAGE THE database...maliciously...
--------------------------------------------------------

		--------------------------------------------------------
		-- Optionally take the database offline and kill or rename the data file!
		--------------------------------------------------------

TRUNCATE TABLE MFG.TABLE1
GO
DELETE MFG.TABLE2
GO
DROP TABLE MFG.TABLE3
GO

--------------------------------------------------------
-- Observe the DAMAGE done...
--------------------------------------------------------

		Select * from MFG.Table1 Order by Col1 DESC	-- Zero rows, table truncated.
		Select * from MFG.Table2 Order by Col1 DESC	-- Zero rows, all rows deleted.
		Select * from MFG.Table3 Order by Col1 DESC	-- The table doesn't even EXIST, so an error will result!

--------------------------------------------------------
-- Back up the Tail of the Log again...
--------------------------------------------------------

Use MASTER
GO

BACKUP LOG [ManufacturingDB] 
TO  DISK = N'C:\BackupDevs\MFG_DB-Tail_Log_Bkup.bak' 
WITH	NO_TRUNCATE 
		, NOFORMAT
		, NOINIT
		,  NAME = N'ManufacturingDB-Transaction Log TAIL Backup'
		, NORECOVERY , CHECKSUM
GO

--------------------------------------------------------
-- Now restore every backup file EXCEPT the final backup, the tail of the log (using the GUI).
	-- The tail would include the "damage" introduced to the database (truncation, deletion, etc.).
	-- This illustrates restoring to a point prior to the end of the log.
--------------------------------------------------------

--------------------------------------------------------
-- Query the tables. All the data has returned.
--------------------------------------------------------

	Select * from MFG.Table1 Order by Col1 DESC
	Select * from MFG.Table2 Order by Col1 DESC
	Select * from MFG.Table3 Order by Col1 DESC

	-- Alternately, display only the largest IDENTITY value in each table...

	Select 'MFG.Table1' as TableName, IDENT_CURRENT('MFG.Table1') As Largest_IDENT_Val
	UNION
	Select 'MFG.Table2' as TableName, IDENT_CURRENT('MFG.Table2') As Largest_IDENT_Val
	UNION
	Select 'MFG.Table3' as TableName, IDENT_CURRENT('MFG.Table3') As Largest_IDENT_Val;

--------------------------------------------------------
-- Cleanup
--------------------------------------------------------

Use Master
GO

Drop Database ManufacturingDB
Go

EXEC master.dbo.sp_DropDevice 
	@LogicalName = N'FullBackupDev'
GO

EXEC master.dbo.sp_DropDevice 
	@LogicalName = N'Differential_BackupDev'
GO

EXEC master.dbo.sp_DropDevice 
	@LogicalName = N'Log_BackupDev'
GO
*/

--------------------------------------------------------
-- Done
--------------------------------------------------------
