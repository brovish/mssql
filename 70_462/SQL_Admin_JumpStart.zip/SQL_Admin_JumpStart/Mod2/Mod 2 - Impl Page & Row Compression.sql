/*

Implementing Data Compression

*/

-- Create Tables with Encryption Settings

Create Database DBWithRedundantData;
GO

Use DBWithRedundantData;
Go 

-- Create a Table Assigning Row Compression

Create Table GreatForRowCompression
(
 Col1 int
,Col2 char(5)
,Col3 char(3)
,Col4 char(2)
) WITH (DATA_Compression = ROW);	-- Notice implementation of Row compression.

-- Create a Table Assigning Page Compression

Create Table GreatForPageCompression
(
 Col1 int
,Col2 nvarchar(5)
,Col3 nvarchar(30)
,Col4 nvarchar(20)
) WITH (DATA_Compression = PAGE);	-- Notice implementation of Page compression, which includes Row compression.

/*
Keep in mind ALTER TABLE and ALTER INDEX can be used
to implement compression when those objects
already exist.

Also, compression could be implemented on a partitioned table with different compression settings per partition!
*/