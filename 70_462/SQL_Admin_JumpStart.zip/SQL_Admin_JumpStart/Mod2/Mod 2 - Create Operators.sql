/*	
--------------------------------
Create Multiple Agent Operators	
--------------------------------

Using SSMS, in Object Explorer navigate to the "SQL Server Agent" node and expand the "Operators" node.
Notice there are no Operators automatically created.

*/

-- Create Operators using code, consisting of system stored procedures.
-- Execute all six of the following sp_Add_Operator statements.

USE [msdb]
GO


EXEC msdb.dbo.sp_add_operator @name=N'DBA_Team', 
		@enabled=1, 
		@weekday_pager_start_time=80000, 
		@weekday_pager_end_time=180000, 
		@saturday_pager_start_time=90000, 
		@saturday_pager_end_time=180000, 
		@sunday_pager_start_time=90000, 
		@sunday_pager_end_time=180000, 
		@pager_days=127, 
		@email_address=N'DBA_Team@Adventureworks.com', 
		@pager_address=N'DBA_Team@Adventureworks.com', 
		@category_name=N'[Uncategorized]', 
		@netsend_address=N'DBA_Team'
GO

EXEC msdb.dbo.sp_add_operator @name=N'DatabaseDev_Team', 
		@enabled=1, 
		@weekday_pager_start_time=80000, 
		@weekday_pager_end_time=180000, 
		@saturday_pager_start_time=90000, 
		@saturday_pager_end_time=180000, 
		@sunday_pager_start_time=90000, 
		@sunday_pager_end_time=180000, 
		@pager_days=62, 
		@email_address=N'DatabaseDev_Team@Adventureworks.com', 
		@pager_address=N'DatabaseDev_Team@Adventureworks.com', 
		@category_name=N'[Uncategorized]', 
		@netsend_address=N'DatabaseDev_Team'
GO

EXEC msdb.dbo.sp_add_operator @name=N'CIO', 
		@enabled=1, 
		@weekday_pager_start_time=100000, 
		@weekday_pager_end_time=140000, 
		@saturday_pager_start_time=90000, 
		@saturday_pager_end_time=180000, 
		@sunday_pager_start_time=90000, 
		@sunday_pager_end_time=180000, 
		@pager_days=62, 
		@email_address=N'CIO@Adventureworks.com', 
		@pager_address=N'CIO@Adventureworks.com', 
		@category_name=N'[Uncategorized]'
GO

EXEC msdb.dbo.sp_add_operator @name=N'DataWarehouse_Team', 
		@enabled=1, 
		@weekday_pager_start_time=80000, 
		@weekday_pager_end_time=180000, 
		@saturday_pager_start_time=80000, 
		@saturday_pager_end_time=180000, 
		@sunday_pager_start_time=90000, 
		@sunday_pager_end_time=180000, 
		@pager_days=126, 
		@email_address=N'DataWarehouse_Team@Adventureworks.com', 
		@pager_address=N'DataWarehouse_Team@Adventureworks.com', 
		@category_name=N'[Uncategorized]'
GO

EXEC msdb.dbo.sp_add_operator @name=N'Storage_Team', 
		@enabled=1, 
		@weekday_pager_start_time=80000, 
		@weekday_pager_end_time=180000, 
		@saturday_pager_start_time=80000, 
		@saturday_pager_end_time=180000, 
		@sunday_pager_start_time=90000, 
		@sunday_pager_end_time=180000, 
		@pager_days=126, 
		@email_address=N'DataWarehouse_Team@Adventureworks.com', 
		@pager_address=N'DataWarehouse_Team@Adventureworks.com', 
		@category_name=N'[Uncategorized]'
GO

EXEC msdb.dbo.sp_add_operator @name=N'DBA_on_call', 
		@enabled=1, 
		@weekday_pager_start_time=0, 
		@weekday_pager_end_time=235959, 
		@saturday_pager_start_time=0, 
		@saturday_pager_end_time=235959, 
		@sunday_pager_start_time=0, 
		@sunday_pager_end_time=235959, 
		@pager_days=127, 
		@email_address=N'DBA_on_call@Adventureworks.com', 
		@pager_address=N'DBA_on_call@Adventureworks.com', 
		@category_name=N'[Uncategorized]'
GO

-- Right click on the "Operators" node under the "SQL Server Agent" node to view the newly created Operators.
-- Right click on one of the Operators, such as "DBATeam" and choose properties to look at the configuration of the Operator.

-- Observe the hours of "DBA_on_call".      :)

-- Best practice: note that an email "alias" or "group/distribution list" is used instead of a specifically named person, like "Bob".
	-- This involves coordination with the email adminstration team.

-----------------------------------------------------------------------
-- Code to Easily Delete Operators, if needed
-----------------------------------------------------------------------

/*

EXEC MSDB.dbo.sp_delete_operator @name = 'DBA_Team';

EXEC MSDB.dbo.sp_delete_operator @name = 'DatabaseDev_Team';

EXEC MSDB.dbo.sp_delete_operator @name = 'CIO';

EXEC MSDB.dbo.sp_delete_operator @name = 'DataWarehouse_Team';

EXEC MSDB.dbo.sp_delete_operator @name = 'Storage_Team';

EXEC MSDB.dbo.sp_delete_operator @name = 'DBA_on_call';

*/


