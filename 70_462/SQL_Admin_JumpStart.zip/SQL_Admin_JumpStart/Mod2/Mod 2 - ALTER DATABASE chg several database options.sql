--------------------------------------------------------
/* 
Creator: George Squillace, SQLPadawan@e-Squillace.com.

--------------------------------------------------------
-- Change various database options.

Make sure you refresh the SQL Server Management Studio (SSMS) "Databases" node after each change.
Observe 
--------------------------------------------------------

*/

--------------------------------------------------------
-- Setup; Add a Table and a couple of rows. 
--------------------------------------------------------

Use TinyDB;
GO

Create Table dbo.T1 (Col1 int Identity, Col2 varchar(20) Default 'Capisce');
GO

Insert dbo.T1 Default Values
Go 5	-- Repeat the batch above five times. DO NOT use a semi-colon to terminate the statement.

--------------------------------------------------------
-- Use ALTER Database to Change Database Availability 
--------------------------------------------------------

USE MASTER;
GO


-- Change AVAILABILITY Options
	Alter database TinyDB
		Set OFFLINE				-- The database is ABSOLUTELY INACCESSIBLE
								-- Cleanly shuts down the database without having to DETACH.
								-- Refresh the Databases node in Mgmt Studio...
									-- ...to notice the change

	-- Try this query to see what happens...  SELECT * FROM PERSON.CONTACT     -- Notice, the DB is unavailable.

	Alter database TinyDB
		Set EMERGENCY			-- limited access (Only SysAdmins). This might be useful for Transaction Log repairs with DBCC.

	-- Try this query to see what happens...  SELECT * FROM dbo.T1    -- Notice, the DB is somewhat available.

	Alter database TinyDB
		Set ONLINE				-- the Default Option

	Alter database TinyDB
		Set READ_ONLY				-- Cannot make changes to the database


	-- Try this query to see what happens...  UPDATE dbo.T1 SET Col2 = 'Capisco'     -- Notice, UPDATEs aren't permitted.

	Alter database TinyDB
		Set READ_WRITE				-- the Default Option

	Alter database TinyDB
		Set SINGLE_USER				-- Only one authoritative user can connect to the database.
							-- Used when DBCC CheckDB repair_allow_data_loss is used.

	Alter database TinyDB
		Set RESTRICTED_USER		

	Alter database TinyDB
		Set MULTI_USER				-- the Default Option

	Alter database TinyDB
		Set ONLINE				-- the Default Option


