--------------------------------------------------------
/* 
Creator: George Squillace, SQLPadawan@e-Squillace.com.

*/

-- THIS is how customer error messages could be used; follow this chain of events...

-- Some application calls... >> 
--      Some Stored Procedure which runs... >> 
--           RAISERROR, which calls some_custom_error_message_number...  >>
--	  	And the custom error message uses WITH_Log...  >>
--                       An ALERT is configured on the Error Message Number!

--------------------------------------------------------
-- Use sp_AddMessage to create a custom error message 
--------------------------------------------------------

Use Master
GO

EXEC sp_AddMessage @MsgNum = 50649
	,@Severity = 7
	,@MsgText = 'The Pulonium P38 Space Modulator is melting the Database.'
	,@with_Log = 'True' 	-- Yes, I DO want the event to be logged.
;

EXEC sp_AddMessage @MsgNum = 50727
	,@Severity = 7
	,@MsgText = 'Send in the Cavalry...we have a situation.'
;	-- This message will not be logged.

--------------------------------------------------------
-- Prove the new message was created...

Select * From sys.messages Where Message_ID > 50000;

--------------------------------------------------------


--------------------------------------------------------
--  Create two more custom error messages...
--------------------------------------------------------

EXEC sp_AddMessage @MsgNum = 50800
	,@Severity = 10
	,@MsgText = 'The addition of this customer did not succeed.'
	,@with_Log = 'False'	-- Notice, no logging for this error message.
;

EXEC sp_AddMessage @MsgNum = 50990
	,@Severity = 12
	,@MsgText = 'The addition of this customer order did not succeed. Try, try again!'
	,@with_Log = 'True'	-- Notice, logging TURNED ON for this error message.
;

--------------------------------------------------------
--  Create a Stored Procedure that calls the custom message...
--------------------------------------------------------

Use MarketDev;		-- Of course, the MarketDEV database must exist for the following code to work.
Go

Create Proc dbo.usp_TestAlertProc
AS
	BEGIN
		Select * from Marketing.Prospect	-- this table must exist for the following code to work.
		RAISERROR (50990, 12, 1) WITH LOG
	END
	; 
GO

--------------------------------------------------------
--  Execute the Stored Procedure that calls the custom message...
--------------------------------------------------------

EXEC dbo.usp_TestAlertProc	-- Observe the text in the "Message" TAB of Management Studio.

-- Consider showing the alert in the Windows Application Log
--	From the Run command type "eventvwr" and hit ENTER.
	-- Expand "Windows logs" and then click on "Application".
	-- The INFORMATION message will likely be at the top of the log...look for Error 50990.

--------------------------------------------------------
--  Create an Alert on the Custom Error Message
--------------------------------------------------------

Use MSDB;
GO

Exec msdb.dbo.sp_add_alert @name=N'Oh_No_Event_50990_on_MarketDev',
	@message_id=50990,
	@severity=0,
	@enabled=1,
	@delay_between_responses=600,
	@include_event_description_in=5,
	@database_name=N'MarketDev',
	@job_id=N'9d9cf888-167e-405a-911f-15a44e43ddf6'	-- This job, of course, must exist
		/* 	Query select * from MSDB.dbo.sysjobs to determine a Job's ID/GUID.	
			You can also use @job_name= instead of @job_id=		*/
GO

EXEC msdb.dbo.sp_add_notification
	@alert_name=N'Oh_No_Event_50990_on_MarketDev',
	@operator_name=N'DBA_on_call',			-- Of course, the operator must exist.
	@notification_method = 1
GO

--------------------------------------------------------
-- Cleanup
--------------------------------------------------------

/*
DROP stuff here or perform other cleanup tasks.
*/

--------------------------------------------------------
-- Done
--------------------------------------------------------
