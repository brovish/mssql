
-----------------------------------------------------------------------
-- Code for Backup Job STEPS
-----------------------------------------------------------------------

/*	SETUP		*/
-- Create the D:\Backups folder.

Use Master;
GO

Exec XP_CMDSHELL 'MD d:\BACKUPs',	no_output

/*
-- Step 1
BACKUP DATABASE [master] 
		TO  DISK = N'D:\BACKUPs\Master.bak' 
		WITH NOFORMAT, INIT,  
		NAME = N'master-Full Database Backup'
		, SKIP, NOREWIND, NOUNLOAD,  STATS = 10, CHECKSUM
		;

-- Step 2
BACKUP DATABASE [msdb] 
		TO  DISK = N'D:\BACKUPs\msdb.bak' 
		WITH NOFORMAT, NOINIT,  
		NAME = N'msdb-Full Database Backup'
		, SKIP, NOREWIND, NOUNLOAD,  STATS = 10, CHECKSUM
		;

-- Step 3
BACKUP DATABASE [model] 
		TO  DISK = N'D:\BACKUPs\model.bak' 
		WITH NOFORMAT, NOINIT,  
		NAME = N'model-Full Database Backup'
		, SKIP, NOREWIND, NOUNLOAD,  STATS = 10, CHECKSUM
		;
*/