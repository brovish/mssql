/*

Implementing Transparent Data Encryption

*/


-------------------------
-- Create Database Master Key
-------------------------

Use Master;
Go

Create Master Key Encryption By Password = 'SuperImportantP@ssw0rdProtection'	
	-- The password above must adhere to the Windows password policy.
	-- could also use a hardware encryption module.

-------------------------
-- Create a Server Certificate Derived from Database Master Key
-------------------------

Use Master;
Go

Create Certificate TDE_Cert With Subject = 'TDE_Encryption_Cert'

-------------------------
-- Create Database Encryption Key for a User Database
-------------------------

Use TinyDB;
Go

Create Database Encryption Key With Algorithm = AES_256
Encryption by Server Certificate TDE_Cert	
	-- The are other algorithm choices but AES_256 is the STRONGEST!
	-- Notice the warning after executing the code!!!

-------------------------
-- Protect User Database
-------------------------

Use Master;
GO

Alter Database TinyDB
SET ENCRYPTION ON;

-------------------------
-- Followup
-------------------------
/*
More than one database can be encrypted using the same same certificate.
Use Master;
GO
Alter Database Some_other_DB	-- replace "Some_other_DB" with an actual database name in the same instance.
SET ENCRYPTION ON;

Back up all keys in the hierarchy to a safe place


In practice TEST moving/restoring the database to another instance. 

*/