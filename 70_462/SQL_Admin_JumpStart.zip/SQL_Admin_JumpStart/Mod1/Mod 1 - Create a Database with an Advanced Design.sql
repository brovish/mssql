
/*   
Create a Database with Advanced Design; Multiple Data and Multiple Filegroups
*/

-- Enable xp_CMDSHELL to run operating system commands within T-SQL code.

EXEC master.dbo.sp_Configure 'Show Advanced Options', 1;

RECONFIGURE;

EXEC master.dbo.sp_Configure 'xp_CmdShell', 1;

RECONFIGURE;
------------------

------------------
-- Make "Drive Letters" to simulate existence of many drive letters (LUNs) 
-- for the advanced database.
------------------

 Use Master
 Go
 EXEC XP_CMDSHELL 'MD c:\Drive_D', 	no_output
 EXEC XP_CMDSHELL 'MD c:\Drive_E', 	no_output
 EXEC XP_CMDSHELL 'MD c:\Drive_F', 	no_output
 EXEC XP_CMDSHELL 'MD c:\Drive_G', 	no_output
 EXEC XP_CMDSHELL 'MD c:\Drive_H', 	no_output
 EXEC XP_CMDSHELL 'MD c:\Drive_I', 	no_output
 EXEC XP_CMDSHELL 'MD c:\Drive_J', 	no_output
 EXEC XP_CMDSHELL 'MD F:\Backups', 	no_output	-- This is for a later demonstration Using M10775A machine MIA-SQL1.
 

-- Use the GUI in SSMS to create a new database with multiple FGs and multiple data files.

------------------
-- Create the AdvancedDB.
------------------

CREATE DATABASE AdvancedDB 
	/*	Script assumes the existence of C:\Drive_D, C:\Drive_E, 
			C:\Drive_F, C:\Drive_G, C:\Drive_H, & C:\Drive_I, 
			to *SIMULATE* multiple disk drives.	*/ 
 ON Primary

------------ NOTICE below non-uniform SIZE, MaxSize, and FileGrowth parameters!
 	(
 	Name = AdvancedDBF1_PrimaryFG
 		,Filename = 'c:\Drive_D\AdvancedDB_F1_PrimaryFG.mdf'
 			,Size = 16MB
 			,MaxSize = 30
 			,FileGrowth = 10%
 	)
 
 , FILEGROUP CurrentDataFG
 	(
 	Name = AdvancedDBF1_CurrentDataFG
 		,Filename = 'c:\Drive_E\AdvancedDB_F1_CDFG.ndf'
 			,Size = 6MB
 			,MaxSize = 15
 			,FileGrowth = 10%
 	)
 
 	,(
 	Name = AdvancedDBF2_CurrentDataFG
 		,Filename = 'c:\Drive_E\AdvancedDB_F2_CDFG.ndf'
 			,Size = 8MB
 			,MaxSize = 12
 			,FileGrowth = 10%
 	) 
 
 , FILEGROUP ArchiveDataFG
 (
 	Name = AdvancedDBF1_ArchiveDataFG
 		,Filename = 'c:\Drive_F\AdvancedDB_F1_AFG.ndf'
 			,Size = 16MB
 			,MaxSize = 100
 			,FileGrowth = 22%
 	)
 
 	,(
 	Name = AdvancedDBF2_ArchiveDataFG
 		,Filename = 'c:\Drive_G\AdvancedDB_F2_AFG.ndf'
 			,Size = 6MB
 			,MaxSize = 10
 			,FileGrowth = 10%
 	)
 
 LOG ON
 	(
 	Name = AdvancedDBLogF1
 		,Filename = 'c:\Drive_H\AdvancedDB_LogF1.ldf'
 			,Size = 6MB
 			,MaxSize = 10
 			,FileGrowth = 10%
 	)
;

------------------
-- Inspect AdvancedDB.
------------------

-- In Object Explorer forcibly refresh the list of databases. (Right click on Databases and choose REFRESH).

-- Right click on AdvancedDB, and choose Properties.
-- Click on both the Filegroups and Files pages to observe the multiple filegroups, and the files in those filegroups.
	-- Make sure you expand the width of the Logical Name, File Type and Filgroup columns.

-- Create a Table (space-occupying object) without specifying a FileGroup

USE AdvancedDB;
GO

Create Table dbo.tbl_Table1
	(
	Col1 nvarchar(20)
	)

-- In Object Explorer expand AdvancedDB, then expand Tables, then right click on dbo.tbl_Table1 and choose Properties.
	-- Click on the Storage page and observe the assigned filegroup, which should be PRIMARY.

-- Create a Table specifying a FileGroup

Create Table dbo.tbl_Table2
	(
	Col1 nvarchar(20)
	)
	ON ArchiveDataFG	-- this assignment designates the placement of the object

-- In Object Explorer expand AdvancedDB, then expand Tables, then right click on dbo.tbl_Table2 and choose Properties.
	-- Click on the Storage page and observe the assigned filegroup, which should be ArchiveDataFG.


------------------
-- Cleanup.
------------------

Use Master;
GO

Drop Database AdvancedDB;
GO


