/*
Module 1 - Working with Collations
*/
-- Use SSMS to make a connection to MIA-SQL1.
-- Obtain the Instance Collation from the GUI.
	-- In Object Explorer right click on the MIA-SQL1 Instance root, choose Properties.
	-- Observer the "Server Collation" property on the General TAB.
--------------------------------------------------------
-- Create a Database without specifying a specific Collation 
--------------------------------------------------------
Create Database UnspecifiedCollationDB;
GO

-- Use the statement below (code) to verify that the new database inherited the System/Instance Collation setting.
USE UnspecifiedCollationDB;
GO

Select DB_Name() AS Current_Database,DATABASEPROPERTYEX('UnspecifiedCollationDB','Collation') AS Collation_Assignment;

-- The new database has the same collation as the instance, and TempDB always has the same collation as the Instance.

--------------------------------------------------------
-- Create a Database with a Collation that overrides the Instance Default Collation 
--------------------------------------------------------

CREATE DATABASE MultiLingualSpeakDB
	COLLATE Arabic_CI_AI;	-- Observe the COLLATE clause

-- Use the GUI to obtain the collation of the new database.
	-- Right click on the MultiLingualSpeakDB Database in Object Explorer, choose Properties.
	-- On the General TAB look under the Maintenance section to see the Collation property.

-- Determine the collation of the MultiLingualSpeakDB in code:

USE MultiLingualSpeakDB;
GO
Select DB_Name() AS Current_Database,DATABASEPROPERTYEX('MultiLingualSpeakDB','Collation') AS Collation_Assignment;

--------------------------------------------------------

--------------------------------------------------------
-- Create Text-based Columns Within a Table with Collations that override the Database Collation 
--------------------------------------------------------

Use MultiLingualSpeakDB;
GO

CREATE Table MixedSpeakTable
	(
	ProductID		INT		IDENTITY
	,EnglishProdName	nvarchar(30)	COLLATE Latin1_General_CI_AI	NOT NULL
	,ArabicProdName		nvarchar(30)					NOT NULL	-- Notice, no collation specified for this column.
	,GreekProdName		nvarchar(30)	COLLATE Greek_CS_AS_KS		NOT NULL
	,JapaneseProdName	nvarchar(30)	COLLATE Japanese_90_CI_AS_KS_WS	NOT NULL
	)
;

-- Use Object Explorer to drill down to the new table, then to one of the columns and observe the 
-- column collation setting.

-- Open a new query window to the tempdb database

USE tempdb;
GO

-- Retrieve and discuss the collation of the system and tempdb

SELECT SERVERPROPERTY('Collation') as SystemCollation,
       DATABASEPROPERTYEX('tempdb','Collation') as DatabaseCollation;
GO

-- Create and populate a table with different column collations with different case sensitivities...

CREATE TABLE dbo.TestCharacter
(
  id int NOT NULL IDENTITY(1,1),
  CIData varchar(10) COLLATE Latin1_General_CI_AS,	-- case insensitive
  CSData varchar(10) COLLATE Latin1_General_CS_AS	-- case sensitive
);

INSERT INTO dbo.TestCharacter (CIData,CSData)
VALUES ('Test Data','Test Data');			-- notice the insertion of mixed case data
GO

-- Execute queries that try to match the same
--         values from each column with all lower case

SELECT * FROM dbo.TestCharacter	
WHERE CIData = 'test data';				-- all lower case text in the WHERE clause

-- Now query the case-sensitive column.

SELECT * FROM dbo.TestCharacter
WHERE CSData = 'test data';	-- No rows returned!

GO

-- Execute a query to perform a case-insensitive
--         search on the case-sensitive data

SELECT * FROM dbo.TestCharacter
WHERE CSData = 'test data' COLLATE Latin1_General_CI_AS;	-- forcibly Collate a particular column
GO

-- Try to execute a query that compares the two columns
--         that have different collations. This will fail
--         as the collation conflict cannot be resolved.

SELECT * FROM dbo.TestCharacter	-- observe an attempt to compare incompatible collations, which will fail
WHERE CIData = CSData;
GO

-- Step 7: Execute the query while specifying a collation

SELECT * FROM dbo.TestCharacter
WHERE CIData = CSData COLLATE Latin1_General_CI_AS;		-- again, forcibly collate, which will be successful.
GO


--------------------------------------------------------

--------------------------------------------------------
-- Cleanup
--------------------------------------------------------

/*
USE MASTER;
GO
DROP Database UnspecifiedCollationDB,MultiLingualSpeakDB;  -- Make sure all connections to these databases are closed first.

*/

--------------------------------------------------------
-- Done
--------------------------------------------------------
