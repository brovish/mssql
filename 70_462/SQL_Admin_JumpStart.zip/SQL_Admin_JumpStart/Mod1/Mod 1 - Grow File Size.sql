/*
Manually increase the size of a Data File Using Code and the GUI
*/

-- First, use Object Explorer and obtain the file sizes from the Model database, which will be used
-- during database creation when initial file sizes are not specified.
-- In Object Explorer expand Databases, then expand System Databases, then right click on Model and choose Properties.
	-- Click on the Files page and observe the initial file sizes, which are likely 3MB for the data file and 1MB for the log file.

-- Create a database not specifying initial sizes...

Create Database TinyDB;
GO

-- In Object Explorer right click Databases, and choose Refresh. The TinyDB should appear.
-- Right click on TinyDB and choose Properties, then click on the Files page. Observe the initial file sizes match the model database.

-- Manually increase the size of the TinyDB data file...

ALTER DATABASE TinyDB MODIFY FILE ( NAME = N'TinyDB', SIZE = 102400KB );
GO

-- Manually increase the size of the TinyDB data file using the GUI...
-- In Object Explorer under the Databases node right click on TinyDB and choose Properties.
	-- Click on the Files page. Click in the Initial Size (MB) section of the data file and type "150" to grow the file.
		-- Grow the log file from "1" to "20".

-- Query a catalog view to determine file sizes in megabytes (MB).

Use TinyDB;
GO

Select DB_Name() AS CurrentDB, Name AS Logical_Filename, ((Size * 8)/1024) AS Size_in_MB from sys.database_files;

--------------
-- If needed, keep the TinyDB for subsequent demonstrations. It is used in the Module 2 MVA demonstrations.
--------------

/*
Use Master;
GO

Drop Database TinyDB;
GO

*/
