--------------------------------------------------------
/* 
Creator: George Squillace, SQLPadawan@e-Squillace.com.

*/


--------------------------------------------------------
-- FIRST, Set a Server-Level Option
--------------------------------------------------------

USE MASTER;
GO

EXEC Master.sys.sp_Configure N'Contained Database Authentication', 1;

--------------------------------------------------------
-- FIRST, Set a Database-Level Option
--------------------------------------------------------

ALTER Database AdvancedDesignDB
SET CONTAINMENT = Partial;
GO

--------------------------------------------------------
-- Create the User in a partially contained database...
--------------------------------------------------------

-- First, using code...

Use AdvancedDesignDB;
GO

Create User SarahBellum		-- Get it?
With Password = N'P@ssw0rd'
, Default_Schema=[Pick_an_actual_Schema]

-- Second, in the GUI

/*
Using Object Explorer in SSMS expand the Databases node, and then expand "AdvancedDesignDB".
	Expand "Security" and then expand "Users".
	Right click on "Users" and choose "New User".
	From the "User type:" list box choose "SQL user with password".
	Supply a user name and password. NOTE, the password MUST meet password policy requirements!
*/

--------------------------------------------------------
-- Authenticate to the Database using the database-level user...
--------------------------------------------------------

/*
Create a new query window in SSMS using the "New Query" button in the Toolbar.
Right click anywhere in the new query window, choose "Connection->" and then choose "Change Connection...".
Choose "SQL Authentication" and supply the username of "SarahBellum" and password of "P@ssw0rd".
Then click on the "Options" button. On the "Connection Properties" TAB manually type the name "AdvancedDesignDB" into the
	"Connect to database:" field and then click on the "Connect" button.
Connection to the AdvancedDesignDB should be successful.
Observe: look at how small the list of available databases is in the database picker in the toolbar!
*/


