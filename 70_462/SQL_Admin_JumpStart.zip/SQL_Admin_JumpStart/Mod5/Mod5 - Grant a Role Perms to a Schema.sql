--------------------------------------------------------
-- Grant a Database ROLE Permissions to a Schema

	/*	Remember, "PRINCIPALs are assigned PERMISSIONs to SECURABLES."	*/
--------------------------------------------------------

-- Connect to the Proseware Instance.

USE Pick_some_database;
GO

GRANT SELECT ON SCHEMA :: Sales	-- Two levels of abstraction (Schema, and Role, instead of Object, and User)
	TO CustomerServiceRole
GO

GRANT Execute ON SCHEMA :: [HumanResources] TO [HumanResourcesTeam_DBRole]
GO


