--------------------------------------------------------
/* 
Creator: George Squillace, SQLPadawan@e-Squillace.com.

*/

-- NOTE: Connect to the Proseware Instance.

--------------------------------------------------------
-- Create (custom) Database Roles
--------------------------------------------------------

USE Pick_some_Database;	-- supply an actual database name.
GO

CREATE ROLE CustomerService_DBRole

CREATE ROLE HumanResourcesTeam_DBRole

CREATE ROLE Manufacturing_ShopFloor_DBRole

--------------------------------------------------------
-- Populate a ROLE with three members using sp_AddRoleMember:
--		#1, A SQL Login
--		#2, A Windows User Login
--		#3, A Windows machine Local Group (MLG) Login
--------------------------------------------------------

--	#1, Add a SQL Login to the role...
sp_AddRoleMember @RoleName = 'CustomerService_DBRole'
	,@MemberName = 'AnakinS'
GO

--	#2, Add a Windows User Login to the role...
sp_AddRoleMember @RoleName = 'CustomerService_DBRole'
	,@MemberName = '[Adventureworks]\BudW'
GO
--	#3, Add a Windows machine Local Group (MLG) Login to the role...
	--FIRST, if the group doesn't already exist make a machine local group using...
			--CREATE LOGIN [[Adventureworks]\MLG-ExecutiveMgmt] FROM WINDOWS WITH DEFAULT_DATABASE = AdventureWorks2008R2

sp_AddRoleMember @RoleName = 'CustomerService_DBRole'
	,@MemberName = '[Adventureworks]\MLG-ExecutiveMgmt'
GO

-- sp_AddRoleMember can also be used to add members to Fixed Database Roles.

sp_AddRoleMember @RoleName = 'DB_DataWriter'
	,@MemberName = '[Adventureworks]\BudW'

-- NOTE: Roles can be nested, or members of other roles.

--------------------------------------------------------
-- Create an Application Role
--------------------------------------------------------
USE AdventureWorks2008R2
GO

CREATE APPLICATION ROLE AppRole_ProcessCustomerOrder
	WITH PASSWORD = '444ReallyIckyPassword555'
GO

--------------------------------------------------------
-- Activate the Application Role using sp_SetAppRole
--------------------------------------------------------

EXEC sp_SetAppRole 'AppRole_ProcessCustomerOrder'
	,'444ReallyIckyPassword555'
GO

-- Note, beginning with SQL 2005 the sp_UnSetAppRole feature became available.


--------------------------------------------------------
-- Done
--------------------------------------------------------


