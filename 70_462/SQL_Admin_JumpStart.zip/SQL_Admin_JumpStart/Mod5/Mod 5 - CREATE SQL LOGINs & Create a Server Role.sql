--------------------------------------------------------
/* 
Creator: George Squillace, SQLPadawan@e-Squillace.com.

--------------------------------------------------------
-- Create SQL Server Logins, a Server Role and Assign it Permissions
--------------------------------------------------------
-- Remember, "Principals are assigned Permissions to Securables".

*/


--------------------------------------------------------
-- FIRST, Add SQL Server Logins	-- Ensure a connection to the Default Instance
--------------------------------------------------------

USE MASTER
GO


CREATE LOGIN AnakinS WITH PASSWORD = 'P@ssw0rd', DEFAULT_DATABASE = MarketDev

CREATE LOGIN Mikey 
	WITH PASSWORD = 'P@ssw0rd'
	, DEFAULT_DATABASE = MarketDev
	, CHECK_POLICY = OFF;  -- Explicit account policy checking turned off; none of the other policy-related checks matter.

CREATE LOGIN Brandi 
	WITH PASSWORD = 'P@ssw0rd'
	, DEFAULT_DATABASE = MarketDev
	, CHECK_POLICY = ON
	, CHECK_EXPIRATION = OFF; -- Password expiration account policy explicitly turned off.

CREATE LOGIN Jane
	WITH PASSWORD = 'P@ssw0rd' 	-- Password change imposed; only applicable if the other two policy options are turned ON.
	, DEFAULT_DATABASE = MarketDev
	, CHECK_POLICY = ON
	, CHECK_EXPIRATION = ON;

CREATE LOGIN Sheila WITH PASSWORD = 'P@ssw0rd', DEFAULT_DATABASE = MarketDev
CREATE LOGIN Rufus WITH PASSWORD = 'P@ssw0rd', DEFAULT_DATABASE = MarketDev

-- Optional

--------------------------------------------------------
-- Assign Server-Scope Role...
--------------------------------------------------------

Create Server Role [SrvConfigAdmins];
GO

Grant Control Server to [SrvConfigAdmins];
GO

ALTER SERVER ROLE [SrvConfigAdmins]
ADD MEMBER [Brandi];
GO

--------------------------------------------------------
-- Assign Server-Scope permissions...
--------------------------------------------------------

USE MASTER;
GO
Grant Control on LOGIN::[Jane] to [Brandi];
Grant Create Any Database to [Mikey];
Grant Connect on ENDPOINT::[TSQL Named Pipes] to [Rufus];
GO