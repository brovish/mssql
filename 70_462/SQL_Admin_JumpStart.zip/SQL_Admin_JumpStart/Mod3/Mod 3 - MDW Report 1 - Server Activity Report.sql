-- Demonstration 3B - Server Activity Usage Report

-- Step 1: Open the MDW Summary Page
--         (In Object Explorer, expand Proseware, expand Databases.
--         Right-click the MDW database, click Reports, click
--         Management Data Warehouse, and click Management Data 
--         Warehouse overview).

-- Step 2: Review the Server Activity Report
--         Note: spend some time reviewing the contents of the report
--         the contents available will depend upon how long the data
--         collectors have been running.
--         (Click a hyperlink under the Server Activity column).

-- Step 3: Close the report window.