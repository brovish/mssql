-- Query workload

-- WARNING:
-- Before executing this query, make sure you have disabled the query
-- results for this window
-- (From the Query menu, click Query Options. Click on Results-Grid
-- (and check Discard results after execution then click OK)

USE MarketDev;
GO

WHILE (1 = 1)
BEGIN
  SELECT p.Color, SUM(p.ListPrice) AS TotalPrice
  FROM Marketing.Product AS p
  GROUP BY p.Color;
  WAITFOR DELAY '00:00:00.500';
END;
GO
