-- Demonstration 3A - Disk Usage Report

-- Note: If you execute Demonstrations 3A, 3B or 3C too soon
--       after the previous demonstrations, no data will have been
--       received yet. You will need to either wait or restore
--       an existing MDW database.


-- Step 1: Force a collection 
--         (In Object Explorer right-click Disk Usage and click
--         Collect and Upload Now then click Close.In Object 
--         Explorer right-click Query Statistics and click
--         Collect and Upload Now then click Close. In Object 
--         Explorer right-click Server Activity and click
--         Collect and Upload Now then click Close).
-

-- Step 2: Open the MDW Summary Page
--         (In Object Explorer, expand Proseware, expand Databases.
--         Right-click the MDW database, click Reports, click
--         Management Data Warehouse, and click Management Data 
--         Warehouse overview). 

-- Step 3: Review the Disk Usage Report
--         Note: spend some time reviewing the contents of the report
--         the contents available will depend upon how long the data
--         collectors have been running.
--         (Click a hyperlink under the Disk Usage column).

-- Step 4: Close the report window.