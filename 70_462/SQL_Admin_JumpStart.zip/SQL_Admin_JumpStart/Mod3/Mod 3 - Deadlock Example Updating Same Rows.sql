--------------------------------------------------------
/* 
Creator: George Squillace, SQLPadawan@e-Squillace.com.

Modification Date(s):	September 6, 2012, added column aliases to the @@SPID queries and some other descriptive information.
Creation Date: 		November 26, 2011.

--------------------------------------------------------
-- Illustrate a Deadlock by Attempting to Update the Same Two Rows in Different Connections
--------------------------------------------------------

This will require opening two query windows (two SPIDs) and running code in both windows.

Optional...for extra drama open up a Profiler session and add all of the events in the Locks Event Class, such as the Deadlock Graph event.
	A deadlock graph will be generated in Profiler during the demo.

*/

--------------------------------------------------------
-- Run Query Code in the First SPID Window
--------------------------------------------------------
Use MarketDev;
GO

----------
-- Show Data beforehand...take note of the names. Maybe type them below for record keeping?
----------

Select Firstname, Lastname From Marketing.Prospect
	Where ProspectID IN(6800,7800);

-- Movie spoiler...two different connections will end up requiring each other's resources.

----------
-- Determine current SPID
----------

Select @@SPID as SPID_1;

----------
-- Begin the update of the first row...
----------

BEGIN TRAN T1;

Update Marketing.Prospect
	Set LastName = 'Smith'
		Where ProspectID = 6800;

----------
-- Show current locks two different ways...
----------

-- Method #1
EXEC sp_Lock;	

-- Method #1
Select * FROM sys.dm_Tran_Locks Where Request_Session_ID = @@SPID;	-- Method #2


----------
-- Open another connection, paste the commented code below into the window and run it.
----------
/*

----------
-- Determine current SPID of second connection
----------

Select @@SPID as SPID_2;

BEGIN TRAN T2;

Update Marketing.Prospect
	Set LastName = 'Jones'
		Where ProspectID = 7800;
*/

----------
-- Return to the first window and run the following code...
----------
Update Marketing.Prospect
	Set FirstName = 'Monica'
		Where ProspectID = 7800;

----------
-- Switch to the second window and add the following code to the window and execute it...
----------

/*
Update Marketing.Prospect
	Set FirstName = 'Sierra'
		Where ProspectID = 6800;	-- This should cause a deadlock.

*/

----------
-- Rollback the first transaction (the second one was the deadlock victim and its transaction was automagically terminated...
----------

ROLLBACK TRAN T1;

----------
-- Query the data to confirm it has returned to its original state...
----------

Select Firstname, Lastname From Marketing.Prospect
	Where ProspectID IN(6800,7800);

--------------------------------------------------------
-- Cleanup
--------------------------------------------------------

/*
No cleanup this time.
*/

--------------------------------------------------------
-- Done
--------------------------------------------------------
