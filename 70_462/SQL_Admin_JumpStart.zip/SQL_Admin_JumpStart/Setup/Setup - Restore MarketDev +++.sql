/*
Setup - Restore MarketDev to ProseWare
*/


USE MASTER:
GO

IF EXISTS(Select 1 from sys.databases Where Name = N'MarketDev')
    DROP Database MarketDev;
GO

Restore Database MarketDev
From Disk = 'F:\SQL_Admin_JumpStart\Setup\MarketDev.bak'
WITH MOVE 'MarketDev' To 'D:\MKTG\MarketDev.mdf',
     MOVE 'MarketDev_Log' TO 'L:\MKTG\MarketDev.ldf';
GO

ALTER Authorization on Database::MarketDev TO [Adventureworks\administrator];

Create Database TinyDB;
GO

Use TinyDB;
GO

Create Table dbo.T1 (Col1 int Identity, Col2 varchar(20) Default 'Capisce');

Insert dbo.T1 Default Values;	-- insert data into the table...for whatever reason.
Insert dbo.T1 Default Values;
Insert dbo.T1 Default Values;
Insert dbo.T1 Default Values;
Insert dbo.T1 Default Values;
Insert dbo.T1 Default Values;
Insert dbo.T1 Default Values;
Insert dbo.T1 Default Values;
Insert dbo.T1 Default Values;


Create Database LogShippingDB;
GO

Create Database MirroringDB;
GO


--------------------------------------------------------
-- Done
--------------------------------------------------------
