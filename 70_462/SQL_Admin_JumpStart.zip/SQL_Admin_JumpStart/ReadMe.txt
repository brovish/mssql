Many but not all of the demonstration query code found in this code collection
are either exact copies of query code in the Microsoft 10775 Database Administration course
or are loosely or tightly based off of that code.