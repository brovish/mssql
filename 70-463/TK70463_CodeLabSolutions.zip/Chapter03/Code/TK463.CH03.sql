-- TK463, Chapter 03

/********************
 * Lesson 3 Practice *
 *********************/

USE TK463;

-- Step 11
-- Execute SQL Task to clean up the tables
TRUNCATE TABLE Production.ProductAndDescription;
TRUNCATE TABLE Production.ProductModelInstructions;

