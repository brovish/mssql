# Apress Source Code

This repository accompanies [*SQL Server 2012 Query Performance Tuning*](http://www.apress.com/9781430242031) by Grant Fritchey and Sajal Dam (Apress, 2012).

![Cover image](9781430242031.jpg)

Download the files as a zip using the green button, or clone the repository to your machine using Git.

## Releases

Release v1.0 corresponds to the code in the published book, without corrections or updates.

## Contributions

See the file Contributing.md for more information on how you can contribute to this repository.
