using System;
using System.Data;
using System.Data.SqlClient;
using System.Data.SqlTypes;
using Microsoft.SqlServer.Server;

public partial class UserDefinedFunctions
{
    [Microsoft.SqlServer.Server.SqlFunction]
    public static SqlInt32 ReturnStringLength1(
        SqlString theString)
    {
        return new SqlInt32 (theString.Value.Length);
    }

    [Microsoft.SqlServer.Server.SqlFunction]
    public static SqlInt32 ReturnStringLength2(
        [SqlFacet(MaxSize=-1)]
        SqlString theString)
    {
        return new SqlInt32(theString.Value.Length);
    }
}
