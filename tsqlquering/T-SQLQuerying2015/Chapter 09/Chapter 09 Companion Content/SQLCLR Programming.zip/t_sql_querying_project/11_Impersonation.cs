using System;
using System.Data;
using System.Data.SqlClient;
using System.Data.SqlTypes;
using Microsoft.SqlServer.Server;

public partial class StoredProcedures
{
    [Microsoft.SqlServer.Server.SqlProcedure]
    public static void Impersonation ()
    {
        var pipe = Microsoft.SqlServer.Server.SqlContext.Pipe;       
        var ident = Microsoft.SqlServer.Server.SqlContext.WindowsIdentity;

        //if the user logged in with SQL authentication the object will be NULL
        if (ident == null)
        {
            pipe.Send("Could not impersonate");
        }
        else
        {
            //otherwise, try to impersonate
            using (var context = ident.Impersonate())
            {
                pipe.Send(String.Format("Successfully impersonated as: {0}", ident.Name));
            }
        }
    }
}
