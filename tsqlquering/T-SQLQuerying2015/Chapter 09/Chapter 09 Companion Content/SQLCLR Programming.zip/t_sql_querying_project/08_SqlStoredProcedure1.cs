using System;
using System.Data;
using System.Data.SqlClient;
using System.Data.SqlTypes;
using Microsoft.SqlServer.Server;

public partial class StoredProcedures
{
    [Microsoft.SqlServer.Server.SqlProcedure]
    public static void SqlStoredProcedure1 ()
    {
        // Put your code here
    }

    [Microsoft.SqlServer.Server.SqlProcedure]
    public static void AddToInput(
        SqlInt32 input,
        out SqlInt32 inputPlusOne,
        out SqlInt32 inputPlusTwo)
    {
        inputPlusOne = input + 1;
        inputPlusTwo = input + 2;
    }
}
