﻿CREATE TABLE [dbo].[MyTable]
(
	[i] INT NOT NULL PRIMARY KEY
)
