using System;
using System.Data;
using System.Data.SqlClient;
using System.Data.SqlTypes;
using Microsoft.SqlServer.Server;

[Serializable]
[Microsoft.SqlServer.Server.SqlUserDefinedAggregate(
    Format.UserDefined, 
    MaxByteSize=-1, 
    IsInvariantToDuplicates=false, 
    IsInvariantToNulls=true
// This one does nothing!
//    IsInvariantToOrder=false
)]
public struct Concatenate : IBinarySerialize
{
    private System.Collections.Generic.List<string> stringList;

    public void Init()
    {
        stringList = new System.Collections.Generic.List<string>();
    }

    public void Accumulate(SqlString Value)
    {
        if (!(Value.IsNull))
            //prepend a comma on each string
            stringList.Add("," + Value.Value);
    }

    public void Merge (Concatenate Group)
    {
        foreach (string s in Group.stringList)
            this.stringList.Add(s);
    }

    public SqlString Terminate ()
    {
        if (stringList.Count == 0)
            return SqlString.Null;
        else
        {
            //remove the comma on the first string
            stringList[0] = stringList[0].Substring(1, stringList[0].Length - 1);
            return new SqlString(string.Concat(stringList.ToArray()));
        }
    }

    public void Read(System.IO.BinaryReader r)
    {
        Init();

        int count = r.ReadInt32();

        while (count > 0)
        {
            stringList.Add(r.ReadString());
            count--;
        }
    }

    public void Write(System.IO.BinaryWriter w)
    {
        w.Write(stringList.Count);

        foreach (string s in stringList)
            w.Write(s);
    }
}
