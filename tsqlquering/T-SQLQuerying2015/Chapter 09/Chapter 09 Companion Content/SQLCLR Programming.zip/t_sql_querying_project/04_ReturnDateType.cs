using System;
using System.Data;
using System.Data.SqlClient;
using System.Data.SqlTypes;
using Microsoft.SqlServer.Server;

public partial class UserDefinedFunctions
{
    [Microsoft.SqlServer.Server.SqlFunction]
    public static DateTimeOffset ReturnDateType()
    {
        // Return the SQL Server 2014 ship date
        return new DateTimeOffset (new DateTime(2014, 04, 01), new TimeSpan(0));
    }
}
