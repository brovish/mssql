using System;
using System.Data;
using System.Data.SqlClient;
using System.Data.SqlTypes;
using Microsoft.SqlServer.Server;

public partial class StoredProcedures
{
    [Microsoft.SqlServer.Server.SqlProcedure]
    public static void DivideByZero ()
    {
        int i = 1;
        int j = 0;
        int k = i / j;
    }

    [Microsoft.SqlServer.Server.SqlProcedure]
    public static void ExecuteASelect()
    {
        var pipe = Microsoft.SqlServer.Server.SqlContext.Pipe;
        var comm = new SqlCommand("SELECT 'this is the result' AS theResult");
        pipe.ExecuteAndSend(comm);
    }

    [Microsoft.SqlServer.Server.SqlProcedure]
    public static void ThrowAnException_v1()
    {
        var pipe = Microsoft.SqlServer.Server.SqlContext.Pipe;
        var comm = new SqlCommand("RAISERROR('test exception', 16, 1)");
        pipe.ExecuteAndSend(comm);
    }

    [Microsoft.SqlServer.Server.SqlProcedure]
    public static void ThrowAnException_v2()
    {
        var pipe = Microsoft.SqlServer.Server.SqlContext.Pipe;
        var comm = new SqlCommand("RAISERROR('test exception', 16, 1)");

        try
        {
            pipe.ExecuteAndSend(comm);
        }
        catch
        { }
    }

    [Microsoft.SqlServer.Server.SqlProcedure]
    public static void DivideByZero_Nicer()
    {
        try
        {
            int i = 1;
            int j = 0;
            int k = i / j;
        }
        catch (Exception e)
        {
            var pipe = Microsoft.SqlServer.Server.SqlContext.Pipe;
            var tsqlThrow = String.Format("RAISERROR('{0}', 16, 1)", e.Message);
            var comm = new SqlCommand(tsqlThrow);

            try
            {
                pipe.ExecuteAndSend(comm);
            }
            catch
            { }
        }
    }

}
