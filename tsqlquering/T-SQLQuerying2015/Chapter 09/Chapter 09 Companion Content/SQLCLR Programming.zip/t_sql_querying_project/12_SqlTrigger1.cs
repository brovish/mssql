using System;
using System.Data;
using System.Data.SqlClient;
using Microsoft.SqlServer.Server;

public partial class Triggers
{        
    [Microsoft.SqlServer.Server.SqlTrigger (Name="SqlTrigger1", Target="MyTable", Event="FOR INSERT, UPDATE")]
    public static void SqlTrigger1 ()
    {
        var build = new SqlConnectionStringBuilder();
        build.ContextConnection = true;

        using (var conn = new SqlConnection(build.ConnectionString))
        {
            var comm = conn.CreateCommand();
            comm.CommandText = "SELECT COUNT(*) FROM inserted";

            conn.Open();

            int rowCount = (int)(comm.ExecuteScalar());

            SqlContext.Pipe.Send(String.Format("Rows affected: {0}", rowCount));
        }
    }
}

