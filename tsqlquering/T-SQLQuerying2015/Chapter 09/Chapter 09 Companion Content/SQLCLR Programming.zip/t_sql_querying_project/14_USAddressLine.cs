using System;
using System.Data;
using System.Data.SqlClient;
using System.Data.SqlTypes;
using Microsoft.SqlServer.Server;


[Serializable]
[Microsoft.SqlServer.Server.SqlUserDefinedType(
    Format.UserDefined,
    MaxByteSize = 82,
    IsFixedLength = false,
    IsByteOrdered = true)]
public struct USAddressLine : INullable, IBinarySerialize
{
    //max byte size assumptions:
    //BuildingNumber <= 8 characters
    //PreDirectional <= 2
    //StreetName <= 25
    //StreetType <= 4
    //PostDirectional <= 2

    public override string ToString()
    {
        return (
            BuildingNumber.Value + " " +
            (PreDirectional.IsNull ? "" : PreDirectional.Value + " ") +
            StreetName.Value + " " +
            StreetType.Value +
            (PostDirectional.IsNull ? "" : " " + PostDirectional.Value));
    }

    public bool IsNull
    {
        get
        {
            // Put your code here
            return _null;
        }
    }

    public static USAddressLine Null
    {
        get
        {
            USAddressLine h = new USAddressLine();
            h._null = true;
            return h;
        }
    }

    public static USAddressLine Parse(SqlString s)
    {
        throw new NotImplementedException("Parse not supported.");
    }

    public static USAddressLine StandardLine(
        SqlString BuildingNumber,
        SqlString StreetName,
        SqlString StreetType)
    {
        var addressLine = new USAddressLine();

        addressLine.BuildingNumber = BuildingNumber;
        addressLine.StreetName = StreetName;
        addressLine.StreetType = StreetType;

        return (addressLine);
    }

    public static USAddressLine PreDirectionalLine(
        SqlString BuildingNumber,
        SqlString PreDirectional,
        SqlString StreetName,
        SqlString StreetType)
    {
        var addressLine = StandardLine(
            BuildingNumber,
            StreetName,
            StreetType);

        addressLine.PreDirectional = PreDirectional;

        return (addressLine);
    }

    public SqlString BuildingNumber
    {
        get { return (_buildingNumber); }
        set { _buildingNumber = validateNull(value); }
    }

    public SqlString StreetName
    {
        get { return (_streetName); }
        set { _streetName = validateNull(value);}
    }

    public SqlString StreetType
    {
        get { return (_streetType); }
        set {_streetType = validateType(validateNull(value));}
    }

    public SqlString PreDirectional
    {
        get { return (_preDirectional); }
        set {_preDirectional = validateDirection(value);}
    }

    public SqlString PostDirectional
    {
        get { return (_postDirectional); }
        set {_postDirectional = validateDirection(value);}
    }

    private SqlString validateNull(SqlString input)
    {
        if (input.IsNull ||
            input.Value.Trim() == "")
            throw new Exception("Attempted to use NULL or a whitespace string in a non-nullable field");

        return (input);
    }

    private SqlString validateDirection(SqlString direction)
    {
        if (!(
            direction.IsNull ||
            direction == "N" ||
            direction == "NE" ||
            direction == "NW" ||
            direction == "E" ||
            direction == "S" ||
            direction == "SE" ||
            direction == "SW" ||
            direction == "W"))
            throw new ArgumentException(String.Format("Invalid direction: {0}", direction.Value));

        return (direction);
    }

    private SqlString validateType(SqlString type)
    {
        if (!(
            type == "ST" ||
            type == "LN" ||
            type == "RD" ||
            type == "WAY" ||
            type == "BLVD" ||
            type == "HWY"))
            throw new ArgumentException(String.Format("Invalid type: {0}", type.Value));

        return (type);
    }

    private SqlString _buildingNumber;
    private SqlString _streetName;
    private SqlString _streetType;
    private SqlString _preDirectional;
    private SqlString _postDirectional;
    
    private bool _null;

    public void Read(System.IO.BinaryReader r)
    {
        _null = r.ReadBoolean();

        if (!_null)
        {
            BuildingNumber = new SqlString(r.ReadString());

            var preDir = r.ReadString();
            if (preDir != "")
                PreDirectional = new SqlString(preDir);

            StreetName = r.ReadString();
            StreetType = r.ReadString();

            var postDir = r.ReadString();
            if (postDir != "")
                PostDirectional = new SqlString(postDir);
        }
    }

    public void Write(System.IO.BinaryWriter w)
    {
        w.Write(_null);

        if (!_null)
        {
            w.Write(BuildingNumber.Value);

            if (!PreDirectional.IsNull)
                w.Write(PreDirectional.Value);
            else
                //represent NULL as an empty string
                w.Write("");

            w.Write(StreetName.Value);
            w.Write(StreetType.Value);

            if (!PostDirectional.IsNull)
                w.Write(PostDirectional.Value);
            else
                w.Write("");
        }
    }
}