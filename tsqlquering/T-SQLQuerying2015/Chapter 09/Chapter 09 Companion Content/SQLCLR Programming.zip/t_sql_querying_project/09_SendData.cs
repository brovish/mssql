using System;
using System.Data;
using System.Data.SqlClient;
using System.Data.SqlTypes;
using Microsoft.SqlServer.Server;

public partial class StoredProcedures
{
    [Microsoft.SqlServer.Server.SqlProcedure]
    public static void SendMessage (SqlString message)
    {
        var pipe = Microsoft.SqlServer.Server.SqlContext.Pipe;
        pipe.Send("The message is: " + message.Value);
    }

    [Microsoft.SqlServer.Server.SqlProcedure]
    public static void SendRows(SqlInt32 numRows)
    {
        //set up the output shape
        var col = new SqlMetaData("col", SqlDbType.Int);
        SqlDataRecord r = new SqlDataRecord(col);
 
        var pipe = Microsoft.SqlServer.Server.SqlContext.Pipe;

        //start the output stream -- this doesn't actually send anything
        pipe.SendResultsStart(r);
        
        //send the rows
        for (int i = 1; i <= numRows.Value; i++)
        {
            //set field 0 (col) to the value
            r.SetInt32(0, i);
            pipe.SendResultsRow(r);
        }

        pipe.SendResultsEnd();
    }
}
