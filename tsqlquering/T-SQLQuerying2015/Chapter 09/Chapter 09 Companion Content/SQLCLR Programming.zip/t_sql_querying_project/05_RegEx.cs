using System;
using System.Data;
using System.Data.SqlClient;
using System.Data.SqlTypes;
using Microsoft.SqlServer.Server;

public partial class UserDefinedFunctions
{
    [Microsoft.SqlServer.Server.SqlFunction]
    public static SqlBoolean RegExMatch(
        SqlString pattern,
        [SqlFacet(MaxSize=-1)]
        SqlString input)
    {
        //handle NULLs
        if (pattern.IsNull || input.IsNull)
            return (SqlBoolean.Null);

        //does the hosting database use a case-sensitive collation?
        var options =
            (0 != (input.SqlCompareOptions & SqlCompareOptions.IgnoreCase)) ?
                System.Text.RegularExpressions.RegexOptions.IgnoreCase :
                System.Text.RegularExpressions.RegexOptions.None;

        //instantiate a regEx object with the options
        var regEx = 
            new System.Text.RegularExpressions.Regex(pattern.Value, options);

        //do we have a match?
        return new SqlBoolean (regEx.IsMatch(input.Value));
    }

    [Microsoft.SqlServer.Server.SqlFunction]
    [return: SqlFacet(MaxSize = -1)]
    public static SqlString RegExReplace(
        SqlString pattern,
        [SqlFacet(MaxSize = -1)]
        SqlString input,
        SqlString replacement)
    {
        //handle NULLs
        if (pattern.IsNull || input.IsNull || replacement.IsNull)
            return (SqlString.Null);

        //does the hosting database use a case-sensitive collation?
        var options =
            (0 != (input.SqlCompareOptions & SqlCompareOptions.IgnoreCase)) ?
                System.Text.RegularExpressions.RegexOptions.IgnoreCase :
                System.Text.RegularExpressions.RegexOptions.None;

        //instantiate a regEx object with the options
        var regEx =
            new System.Text.RegularExpressions.Regex(pattern.Value, options);

        //do we have a match?
        return new SqlString(regEx.Replace(input.Value, replacement.Value));
    }
}
