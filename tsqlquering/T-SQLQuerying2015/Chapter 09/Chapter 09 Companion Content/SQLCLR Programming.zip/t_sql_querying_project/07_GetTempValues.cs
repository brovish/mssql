using System;
using System.Data;
using System.Data.SqlClient;
using System.Data.SqlTypes;
using Microsoft.SqlServer.Server;

public partial class UserDefinedFunctions
{
    [Microsoft.SqlServer.Server.SqlFunction(
        DataAccess=DataAccessKind.Read,
        TableDefinition="col1 INT, col2 FLOAT",
        FillRowMethodName="GetTempValues_fill")]
    public static System.Collections.IEnumerable GetTempValues()
    {
        var build = new SqlConnectionStringBuilder();
        build.ContextConnection = true;

        using (var conn = new SqlConnection(build.ConnectionString))
        {
            var comm = conn.CreateCommand();
            comm.CommandText = "SELECT * FROM #values";

            var adapter = new SqlDataAdapter(comm);

            var dt = new DataTable();
            adapter.Fill(dt);

            return (dt.Rows);
        }
    }

    public static void GetTempValues_fill(
        object o,
        out SqlInt32 col1,
        out SqlDouble col2)
    {
        var dr = (DataRow)o;
        col1 = new SqlInt32((int)dr[0]);
        col2 = new SqlDouble((double)dr[1]);
    }
}
