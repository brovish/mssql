using System;
using System.Data;
using System.Data.SqlClient;
using System.Data.SqlTypes;
using Microsoft.SqlServer.Server;

public partial class UserDefinedFunctions
{
    [Microsoft.SqlServer.Server.SqlFunction(
        TableDefinition="value NVARCHAR(MAX)",
        FillRowMethodName="StringSplit_fill")]
    public static System.Collections.IEnumerable StringSplit(
        [SqlFacet(MaxSize=-1)]
        SqlString input)
    {
        if (input.IsNull)
            return (new string[] {});
        else
            return (input.Value.Split(','));
    }

    public static void StringSplit_fill(
        object o,
        out SqlString value)
    {
        value = (string)o;
    }
}
